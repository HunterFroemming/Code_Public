noun1 = ""
noun2 = ""
noun3 = ""
noun4 = ""
noun5 = ""
verb1 = ""
verb2 = ""
verb3 = ""
verb4 = ""
verb5 = ""
adjective1 = ""
adjective2 = ""
adjective3 = ""
adjective4 = ""
adjective5 = ""


def ask_the_questions():
    print("Now I will ask some questions.")
    global noun1
    global noun2
    global noun3
    global noun4
    global noun5
    global verb1
    global verb2
    global verb3
    global verb4
    global verb5
    global adjective1
    global adjective2
    global adjective3
    global adjective4
    global adjective5
    noun1 = input("Please enter a noun")
    verb1 = input("Thank you. Now please enter a verb.")
    adjective1 = input("Keep it up, give me an adjective.")
    noun2 = input("Please enter a noun")
    verb2 = input("Thank you. Now please enter a verb.")
    adjective2 = input("Keep it up, give me an adjective.")
    noun3 = input("Please enter a noun")
    verb3 = input("Thank you. Now please enter a verb.")
    adjective3 = input("Keep it up, give me an adjective.")
    noun4 = input("Please enter a noun")
    verb4 = input("Thank you. Now please enter a verb.")
    adjective4 = input("Keep it up, give me an adjective.")
    noun5 = input("Please enter a noun")
    verb5 = input("Thank you. Now please enter a verb.")
    adjective5 = input("Keep it up, give me an adjective.")


def reveal_the_story():
    print("Are you ready?")
    print("Welcome to the story. You just ran into a "+noun1+"." "You did this while "+verb1+", how silly." "You "+adjective1+" yourself.")
    print("You then got up and "+verb2+"." "You feel "+adjective2+"." "You come across a(n) "+noun2+"." "You begin to "+verb3+"." )
    print("You then ran to the "+noun3+"." "Once you arrived at the "+noun3+", you became "+adjective3+"." "At the "+noun3+",you met "+noun4+".")
    print(""+noun4+" is happy to see you." ""+noun4+" looks "+adjective4+" while he "+verb4+"." "You both then begin to "+verb5+" to the "+noun5+" that is "+adjective5+".")


if __name__ == '__main__':
    ask_the_questions()
    reveal_the_story()